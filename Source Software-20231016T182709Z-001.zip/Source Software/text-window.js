const { app, BrowserWindow } = require('electron');
const { spawn } = require('child_process');

let mainWindow;

app.on('ready', () => {
    mainWindow = new BrowserWindow({
        width: 400, 
        height: 150, 
        frame: false, 
        transparent: true, 
        alwaysOnTop: true, 
    });

    mainWindow.loadFile('text-window.html');

    const appProcess = spawn('node', ['api.js']);

    mainWindow.on('closed', () => {
        appProcess.kill();
        mainWindow = null;
    });
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit();
    }
});
