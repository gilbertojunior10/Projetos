const { app, BrowserWindow } = require('electron');
let mainWindow;
let mainWindow2;

app.allowRendererProcessReuse = false;

app.on('ready', () => {
  mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
  });

  mainWindow.loadFile('index.html');

  console.log('Iniciando a API...');

  require('./api.js');
  global.mainWindow = mainWindow;

  mainWindow.on('closed', () => {
    mainWindow = null;
    mainWindow2 = null;
    if (process.platform !== 'darwin') {
      app.quit();
    }
  });

  mainWindow2 = new BrowserWindow({
    width: 800,
    height: 100,
    frame: false,
    transparent: true,
    alwaysOnTop: true,
  });

  mainWindow.maximize()
  mainWindow2.loadFile('text-window.html');
  global.mainWindow2 = mainWindow2;

});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});