const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;
const os = require('os');


app.use(bodyParser.json());

app.post('/txtParcial', (req, res) => {
  const partialText = req.body.mensagem;
  mainWindow2.webContents.executeJavaScript(`setTexto('${partialText}')`);
  mainWindow.webContents.executeJavaScript(`setTextoParcial('${partialText}')`)
  res.status(200).send('Texto Parcial Recebido com Sucesso');
});

app.post('/txtFinal', (req, res) => {
  const finalText = req.body.mensagem;;
  mainWindow.webContents.executeJavaScript(`NovoTextoFinal('${finalText}')`);
  res.status(200).send('Texto Final Recebido com Sucesso');
});

const networkInterfaces = os.networkInterfaces();
for (const ifaceName in networkInterfaces) {
  const iface = networkInterfaces[ifaceName];
  for (const alias of iface) {
    if (alias.family === 'IPv4' && !alias.internal) {
      ip = alias.address;
      break;
    }
  }
  if (ip) {
    break;
  }
}

app.listen(3000, ip, () => {
  console.log(`Iniciando API em ${ip}:3000`)
  mainWindow.webContents.executeJavaScript(`criarQRCode('${ip}')`);
});