document.addEventListener("DOMContentLoaded", function () {
});

function setTexto(text){
    document.getElementById('texto').innerHTML = text;
}