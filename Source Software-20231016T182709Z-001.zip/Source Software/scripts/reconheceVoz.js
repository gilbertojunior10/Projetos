const texts = document.querySelector(".texts");

let ipServidor = "localhost"

window.SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

const recognition = new SpeechRecognition();
recognition.interimResults = true;

let p = document.createElement("p");

function enviarMsg(mensagem){
    fetch('http://'+ipServidor+':3000/mensagens', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ mensagem })
    })
}

recognition.addEventListener("result", (e) => {
  document.body.appendChild(p);
  let text = Array.from(e.results)
    .map((result) => result[0])
    .map((result) => result.transcript)
    .join("");

  p.innerText = text;

  fetch('http://'+ipServidor+':3000/txtAtual', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ text })
    })
  
  if (e.results[0].isFinal) {
    if (text.endsWith("?")) {
      text += "?"; 
      p.innerText = text;
    } else {
      text += ".";
      p.innerText = text;
    }

    mensagem = text;

    fetch('http://'+ipServidor+':3000/mensagens', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ mensagem })
    })
    fetch('http://'+ipServidor+':3000/txtAtual', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify()
    })
    p = document.createElement("p");
  }
});

recognition.addEventListener("end", () => {
  recognition.start();
});

document.addEventListener("DOMContentLoaded", (event) => {
    navigator.mediaDevices.getUserMedia({ audio: true });
    recognition.start();
});
