let txtParcial
let listaTxts

addEventListener("DOMContentLoaded", (event) => {
    txtParcial = document.getElementById('textoAtual')
    listaTxts = document.getElementById('listaTextos')
});

function criarQRCode(texto) {
    let qrcode = new QRCode(document.getElementById("qrcode"), {
      text: texto,
      width: 180,
      height: 180,
    });
}

function setTextoParcial(text){
    txtParcial.innerHTML = text;
}

function NovoTextoFinal(text){
    let novoP = document.createElement('p');
    novoP.innerHTML = text;
    listaTxts.appendChild(novoP);
}